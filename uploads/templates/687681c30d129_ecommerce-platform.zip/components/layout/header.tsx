"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { usePathname } from "next/navigation"
import { Menu, Search, ShoppingBag, User } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet"
import { Input } from "@/components/ui/input"
import { useCart } from "@/context/cart-context"
import { useAuth } from "@/context/auth-context"
import { cn } from "@/lib/utils"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Sidebar } from "@/components/navigation/sidebar"
import { useIsMobile } from "@/hooks/use-mobile"
import { MegaMenuNew } from "@/components/navigation/mega-menu-new"

const mainCategories = [
  { name: "MEN", href: "/category/men" },
  { name: "WOMEN", href: "/category/women" },
  { name: "KIDS", href: "/category/kids" },
  { name: "HOME", href: "/category/home" },
  { name: "BEAUTY", href: "/category/beauty" },
  { name: "GENZ", href: "/category/genz" },
  { name: "STUDIO", href: "/category/studio", isNew: true },
]

export default function Header() {
  const [isScrolled, setIsScrolled] = useState(false)
  const [isSidebarOpen, setIsSidebarOpen] = useState(false)
  const [isSearchOpen, setIsSearchOpen] = useState(false)
  const [activeCategory, setActiveCategory] = useState<string | null>(null)
  const [isMegaMenuOpen, setIsMegaMenuOpen] = useState(false)
  const [hoverTimeout, setHoverTimeout] = useState<NodeJS.Timeout | null>(null)
  const pathname = usePathname()
  const { cartItems } = useCart()
  const { user, logout } = useAuth()
  const isMobile = useIsMobile()

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 10)
    }
    window.addEventListener("scroll", handleScroll)
    return () => window.removeEventListener("scroll", handleScroll)
  }, [])

  const handleCategoryHover = (category: string) => {
    if (!isMobile) {
      if (hoverTimeout) {
        clearTimeout(hoverTimeout)
      }
      setActiveCategory(category)
    }
  }

  const handleCategoryLeave = () => {
    if (!isMobile) {
      const timeout = setTimeout(() => {
        setActiveCategory(null)
      }, 200)
      setHoverTimeout(timeout)
    }
  }

  const handleMegaMenuHover = () => {
    if (hoverTimeout) {
      clearTimeout(hoverTimeout)
    }
  }

  const handleCategoryClick = (category: string) => {
    if (isMobile) {
      setActiveCategory(category)
      setIsMegaMenuOpen(true)
    }
  }

  const closeMegaMenu = () => {
    setIsMegaMenuOpen(false)
    setActiveCategory(null)
    if (hoverTimeout) {
      clearTimeout(hoverTimeout)
    }
  }

  return (
    <>
      <header
        className={cn(
          "sticky top-0 z-50 w-full transition-all duration-200 border-b border-accent bg-white",
          isScrolled ? "shadow-lg" : "",
        )}
      >
        <div className="container px-4 md:px-6">
          <div className="flex h-16 items-center justify-between">
            <div className="flex items-center gap-4">
              <Sheet open={isSidebarOpen} onOpenChange={setIsSidebarOpen}>
                <SheetTrigger asChild className="md:hidden">
                  <Button variant="ghost" size="icon" aria-label="Menu" className="text-primary hover:bg-accent">
                    <Menu className="h-5 w-5" />
                  </Button>
                </SheetTrigger>
                <SheetContent side="left" className="w-[300px] sm:w-[350px] bg-background p-0">
                  <Sidebar onClose={() => setIsSidebarOpen(false)} />
                </SheetContent>
              </Sheet>
              <Link href="/" className="font-bold text-xl text-primary hover:text-secondary transition-colors">
                Fashion Store
              </Link>
            </div>

            <nav className="hidden md:flex items-center relative">
              {mainCategories.map((category) => (
                <div
                  key={category.name}
                  className="relative"
                  onMouseEnter={() => handleCategoryHover(category.name)}
                  onMouseLeave={handleCategoryLeave}
                >
                  <Link
                    href={category.href}
                    className={cn(
                      "text-sm font-semibold px-6 py-5 inline-block transition-all duration-200 hover:text-primary relative",
                      pathname.startsWith(category.href) ? "text-primary" : "text-foreground",
                      activeCategory === category.name && "text-primary bg-accent/20",
                    )}
                    onClick={() => handleCategoryClick(category.name)}
                  >
                    {category.name}
                    {category.isNew && (
                      <span className="ml-2 text-[10px] font-bold text-white bg-secondary px-2 py-1 rounded uppercase">
                        New
                      </span>
                    )}
                    {activeCategory === category.name && (
                      <div className="absolute bottom-0 left-0 right-0 h-1 bg-primary rounded-t"></div>
                    )}
                  </Link>
                </div>
              ))}

              {/* Mega Menu Container - positioned relative to nav */}
              {activeCategory && !isMobile && (
                <div
                  className="absolute top-full left-0 w-screen"
                  onMouseEnter={handleMegaMenuHover}
                  onMouseLeave={handleCategoryLeave}
                  style={{ marginLeft: "calc(-50vw + 50%)" }}
                >
                  <MegaMenuNew category={activeCategory} isOpen={true} onClose={closeMegaMenu} />
                </div>
              )}
            </nav>

            <div className="flex items-center gap-2">
              <Sheet open={isSearchOpen} onOpenChange={setIsSearchOpen}>
                <SheetTrigger asChild>
                  <Button
                    variant="ghost"
                    size="icon"
                    aria-label="Search"
                    className="text-primary hover:bg-accent hover:text-secondary transition-colors"
                  >
                    <Search className="h-5 w-5" />
                  </Button>
                </SheetTrigger>
                <SheetContent side="top" className="h-[120px] bg-background border-b-2 border-primary">
                  <div className="flex h-full items-center justify-center">
                    <div className="relative w-full max-w-lg">
                      <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                      <Input
                        type="search"
                        placeholder="Search for products, brands and more..."
                        className="w-full pl-10 border-accent focus:border-primary"
                        autoFocus
                      />
                    </div>
                  </div>
                </SheetContent>
              </Sheet>

              <div className="hidden md:block">
                {user ? (
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button
                        variant="ghost"
                        size="icon"
                        aria-label="Account"
                        className="text-primary hover:bg-accent transition-colors"
                      >
                        <Avatar className="h-8 w-8 bg-accent border-2 border-primary/20">
                          <AvatarImage src="/placeholder-user.jpg" alt={user.firstName} />
                          <AvatarFallback className="text-primary font-semibold">
                            {user.firstName.charAt(0)}
                          </AvatarFallback>
                        </Avatar>
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent
                      align="end"
                      className="w-56 bg-background border-accent shadow-lg"
                      sideOffset={5}
                    >
                      <DropdownMenuLabel className="text-primary">My Account</DropdownMenuLabel>
                      <DropdownMenuSeparator className="bg-accent" />
                      <DropdownMenuItem asChild className="hover:bg-accent focus:bg-accent">
                        <Link href="/account" className="flex items-center">
                          Profile
                        </Link>
                      </DropdownMenuItem>
                      <DropdownMenuItem asChild className="hover:bg-accent focus:bg-accent">
                        <Link href="/orders" className="flex items-center">
                          Orders
                        </Link>
                      </DropdownMenuItem>
                      <DropdownMenuItem asChild className="hover:bg-accent focus:bg-accent">
                        <Link href="/wishlist" className="flex items-center">
                          Wishlist
                        </Link>
                      </DropdownMenuItem>
                      <DropdownMenuSeparator className="bg-accent" />
                      <DropdownMenuItem onClick={logout} className="hover:bg-accent focus:bg-accent text-secondary">
                        Sign Out
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                ) : (
                  <Button
                    variant="ghost"
                    size="icon"
                    aria-label="Account"
                    asChild
                    className="text-primary hover:bg-accent hover:text-secondary transition-colors"
                  >
                    <Link href="/login">
                      <User className="h-5 w-5" />
                    </Link>
                  </Button>
                )}
              </div>

              <Link href="/cart">
                <Button
                  variant="ghost"
                  size="icon"
                  aria-label="Cart"
                  className="relative text-primary hover:bg-accent hover:text-secondary transition-colors"
                >
                  <ShoppingBag className="h-5 w-5" />
                  {cartItems.length > 0 && (
                    <Badge className="absolute -right-1 -top-1 h-5 w-5 rounded-full p-0 flex items-center justify-center bg-secondary text-white text-xs font-bold border-2 border-background">
                      {cartItems.length}
                    </Badge>
                  )}
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </header>

      {/* Mobile Mega Menu */}
      {isMobile && activeCategory && (
        <MegaMenuNew category={activeCategory} isOpen={isMegaMenuOpen} onClose={closeMegaMenu} />
      )}
    </>
  )
}
