"use client"

import Link from "next/link"
import { Facebook, Instagram, Twitter } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { useIsMobile } from "@/hooks/use-mobile"

export default function Footer() {
  const isMobile = useIsMobile()

  // Simplified footer for mobile view
  if (isMobile) {
    return (
      <footer className="border-t bg-background py-4">
        <div className="container px-4 text-center">
          <div className="flex justify-center space-x-4 mb-4">
            <Button variant="ghost" size="icon" aria-label="Facebook" className="text-primary">
              <Facebook className="h-5 w-5" />
            </Button>
            <Button variant="ghost" size="icon" aria-label="Twitter" className="text-primary">
              <Twitter className="h-5 w-5" />
            </Button>
            <Button variant="ghost" size="icon" aria-label="Instagram" className="text-primary">
              <Instagram className="h-5 w-5" />
            </Button>
          </div>
          <p className="text-xs text-muted-foreground">
            &copy; {new Date().getFullYear()} Fashion Store. All rights reserved.
          </p>
        </div>
      </footer>
    )
  }

  // Full footer for desktop view
  return (
    <footer className="border-t bg-background">
      <div className="container px-4 md:px-6 py-8 md:py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          <div className="space-y-4">
            <h3 className="text-lg font-semibold text-primary">Fashion Store</h3>
            <p className="text-sm text-muted-foreground">
              Your one-stop destination for all your fashion needs. Quality products, competitive prices, and
              exceptional service.
            </p>
            <div className="flex space-x-4">
              <Button variant="ghost" size="icon" aria-label="Facebook" className="text-primary">
                <Facebook className="h-5 w-5" />
              </Button>
              <Button variant="ghost" size="icon" aria-label="Twitter" className="text-primary">
                <Twitter className="h-5 w-5" />
              </Button>
              <Button variant="ghost" size="icon" aria-label="Instagram" className="text-primary">
                <Instagram className="h-5 w-5" />
              </Button>
            </div>
          </div>
          <div className="space-y-4">
            <h3 className="text-lg font-semibold text-primary">Shop</h3>
            <ul className="space-y-2 text-sm">
              <li>
                <Link href="/category/men" className="hover:text-primary">
                  Men
                </Link>
              </li>
              <li>
                <Link href="/category/women" className="hover:text-primary">
                  Women
                </Link>
              </li>
              <li>
                <Link href="/category/kids" className="hover:text-primary">
                  Kids
                </Link>
              </li>
              <li>
                <Link href="/category/home" className="hover:text-primary">
                  Home
                </Link>
              </li>
              <li>
                <Link href="/category/beauty" className="hover:text-primary">
                  Beauty
                </Link>
              </li>
            </ul>
          </div>
          <div className="space-y-4">
            <h3 className="text-lg font-semibold text-primary">Customer Service</h3>
            <ul className="space-y-2 text-sm">
              <li>
                <Link href="/contact" className="hover:text-primary">
                  Contact Us
                </Link>
              </li>
              <li>
                <Link href="/shipping" className="hover:text-primary">
                  Shipping & Returns
                </Link>
              </li>
              <li>
                <Link href="/faq" className="hover:text-primary">
                  FAQ
                </Link>
              </li>
              <li>
                <Link href="/size-guide" className="hover:text-primary">
                  Size Guide
                </Link>
              </li>
              <li>
                <Link href="/terms" className="hover:text-primary">
                  Terms & Conditions
                </Link>
              </li>
            </ul>
          </div>
          <div className="space-y-4">
            <h3 className="text-lg font-semibold text-primary">Newsletter</h3>
            <p className="text-sm text-muted-foreground">
              Subscribe to our newsletter to receive updates on new arrivals, special offers, and other discount
              information.
            </p>
            <div className="flex space-x-2">
              <Input type="email" placeholder="Your email" className="max-w-[220px] border-accent" />
              <Button className="bg-primary hover:bg-secondary">Subscribe</Button>
            </div>
          </div>
        </div>
        <div className="mt-8 pt-8 border-t border-accent text-center text-sm text-muted-foreground">
          <p>&copy; {new Date().getFullYear()} Fashion Store. All rights reserved.</p>
        </div>
      </div>
    </footer>
  )
}
