"use client"

import { useState } from "react"
import Link from "next/link"
import Image from "next/image"
import { Heart } from "lucide-react"
import { Button } from "@/components/ui/button"
import { useCart } from "@/context/cart-context"
import { useToast } from "@/hooks/use-toast"

const products = [
  {
    id: 1,
    name: "Cotton T-Shirt",
    price: 29.99,
    image: "/placeholder.svg?height=400&width=300",
    slug: "cotton-t-shirt",
    category: "men",
  },
  {
    id: 2,
    name: "Slim Fit Jeans",
    price: 59.99,
    image: "/placeholder.svg?height=400&width=300",
    slug: "slim-fit-jeans",
    category: "men",
  },
  {
    id: 3,
    name: "Summer Dress",
    price: 49.99,
    image: "/placeholder.svg?height=400&width=300",
    slug: "summer-dress",
    category: "women",
  },
  {
    id: 4,
    name: "Leather Jacket",
    price: 199.99,
    image: "/placeholder.svg?height=400&width=300",
    slug: "leather-jacket",
    category: "women",
  },
]

export function FeaturedProducts() {
  const { addToCart } = useCart()
  const { toast } = useToast()
  const [wishlist, setWishlist] = useState<number[]>([])

  const toggleWishlist = (productId: number) => {
    if (wishlist.includes(productId)) {
      setWishlist(wishlist.filter((id) => id !== productId))
      toast({
        title: "Removed from wishlist",
        description: "The product has been removed from your wishlist",
      })
    } else {
      setWishlist([...wishlist, productId])
      toast({
        title: "Added to wishlist",
        description: "The product has been added to your wishlist",
      })
    }
  }

  const handleAddToCart = (product: any) => {
    addToCart({
      id: product.id,
      name: product.name,
      price: product.price,
      image: product.image,
      quantity: 1,
    })
    toast({
      title: "Added to cart",
      description: `${product.name} has been added to your cart`,
    })
  }

  return (
    <section className="container px-4 md:px-6 py-8 md:py-12">
      <h2 className="text-2xl font-bold tracking-tight text-center mb-8 text-primary">Featured Products</h2>
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 md:gap-6">
        {products.map((product) => (
          <div key={product.id} className="group relative border border-accent rounded-lg overflow-hidden">
            <div className="aspect-square overflow-hidden">
              <Image
                src={product.image || "/placeholder.svg"}
                alt={product.name}
                width={300}
                height={400}
                className="h-full w-full object-cover transition-transform duration-300 group-hover:scale-105"
              />
            </div>
            <Button
              variant="ghost"
              size="icon"
              className="absolute right-2 top-2 bg-white/80 backdrop-blur-sm rounded-full text-primary"
              onClick={() => toggleWishlist(product.id)}
            >
              <Heart className={`h-5 w-5 ${wishlist.includes(product.id) ? "fill-primary text-primary" : ""}`} />
            </Button>
            <div className="p-4">
              <Link href={`/product/${product.slug}`}>
                <h3 className="font-medium text-base mb-1 group-hover:text-primary">{product.name}</h3>
              </Link>
              <p className="font-semibold text-secondary">${product.price.toFixed(2)}</p>
              <Button className="w-full mt-3 bg-primary hover:bg-secondary" onClick={() => handleAddToCart(product)}>
                Add to Cart
              </Button>
            </div>
          </div>
        ))}
      </div>
      <div className="text-center mt-8">
        <Button variant="outline" asChild className="border-primary text-primary hover:bg-accent">
          <Link href="/products">View All Products</Link>
        </Button>
      </div>
    </section>
  )
}
