import Link from "next/link"
import { Button } from "@/components/ui/button"

export function HeroSection() {
  return (
    <section className="relative">
      <div className="absolute inset-0 bg-gradient-to-r from-black/60 to-black/30" />
      <div
        className="relative h-[60vh] md:h-[70vh] flex items-center justify-start bg-cover bg-center"
        style={{ backgroundImage: "url('/placeholder.svg?height=1080&width=1920')" }}
      >
        <div className="container px-4 md:px-6">
          <div className="max-w-md space-y-4 text-white">
            <h1 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">Summer Collection 2025</h1>
            <p className="text-cream">
              Discover the latest trends in fashion and explore our new collection of clothing, shoes, and accessories.
            </p>
            <div className="flex flex-col sm:flex-row gap-3">
              <Button size="lg" className="bg-primary hover:bg-secondary" asChild>
                <Link href="/category/women">Shop Women</Link>
              </Button>
              <Button
                size="lg"
                variant="outline"
                className="bg-white/10 text-white border-white/20 hover:bg-white/20"
                asChild
              >
                <Link href="/category/men">Shop Men</Link>
              </Button>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
