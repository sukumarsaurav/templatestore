import Link from "next/link"
import { Button } from "@/components/ui/button"

export function PromoSection() {
  return (
    <section className="bg-muted py-12 md:py-16">
      <div className="container px-4 md:px-6">
        <div className="grid md:grid-cols-2 gap-8 items-center">
          <div className="space-y-4">
            <h2 className="text-2xl md:text-3xl font-bold tracking-tight">Summer Sale</h2>
            <p className="text-muted-foreground">
              Enjoy up to 50% off on selected items. Limited time offer, shop now and save big on your favorite styles.
            </p>
            <Button asChild>
              <Link href="/sale">Shop the Sale</Link>
            </Button>
          </div>
          <div
            className="h-[300px] rounded-lg bg-cover bg-center"
            style={{ backgroundImage: "url('/placeholder.svg?height=600&width=800')" }}
          />
        </div>
      </div>
    </section>
  )
}
