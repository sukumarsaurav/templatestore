import Link from "next/link"
import Image from "next/image"

const categories = [
  {
    name: "Men",
    image: "/placeholder.svg?height=600&width=400",
    href: "/category/men",
  },
  {
    name: "Women",
    image: "/placeholder.svg?height=600&width=400",
    href: "/category/women",
  },
  {
    name: "Kids",
    image: "/placeholder.svg?height=600&width=400",
    href: "/category/kids",
  },
  {
    name: "Home",
    image: "/placeholder.svg?height=600&width=400",
    href: "/category/home",
  },
]

export function CategoryShowcase() {
  return (
    <section className="container px-4 md:px-6 py-8 md:py-12">
      <h2 className="text-2xl font-bold tracking-tight text-center mb-8">Shop by Category</h2>
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 md:gap-6">
        {categories.map((category) => (
          <Link key={category.name} href={category.href} className="group relative overflow-hidden rounded-lg">
            <div className="absolute inset-0 bg-black/30 group-hover:bg-black/40 transition-colors z-10" />
            <Image
              src={category.image || "/placeholder.svg"}
              alt={category.name}
              width={400}
              height={600}
              className="h-[200px] md:h-[300px] w-full object-cover transition-transform duration-300 group-hover:scale-105"
            />
            <div className="absolute inset-0 flex items-center justify-center z-20">
              <h3 className="text-xl md:text-2xl font-bold text-white">{category.name}</h3>
            </div>
          </Link>
        ))}
      </div>
    </section>
  )
}
