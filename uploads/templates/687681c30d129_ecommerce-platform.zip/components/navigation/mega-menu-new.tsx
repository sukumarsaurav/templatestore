"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { ChevronRight, X } from "lucide-react"
import { Button } from "@/components/ui/button"
import { useIsMobile } from "@/hooks/use-mobile"

interface MegaMenuNewProps {
  category: string
  isOpen: boolean
  onClose: () => void
}

// Simplified and clean data structure
const subcategories = {
  MEN: {
    featured: [
      { name: "New Arrivals", href: "/category/men/new-arrivals", badge: "NEW", badgeColor: "bg-primary" },
      { name: "Bestsellers", href: "/category/men/bestsellers" },
      { name: "Sale", href: "/category/men/sale", badge: "SALE", badgeColor: "bg-secondary" },
    ],
    categories: [
      {
        title: "Topwear",
        items: ["T-Shirts", "Casual Shirts", "Formal Shirts", "Sweatshirts", "Sweaters", "Jackets"],
      },
      {
        title: "Bottomwear",
        items: ["Jeans", "Casual Trousers", "Formal Trousers", "Shorts", "Track Pants"],
      },
      {
        title: "Footwear",
        items: ["Casual Shoes", "Sports Shoes", "Formal Shoes", "Sneakers", "Sandals"],
      },
      {
        title: "Accessories",
        items: ["Watches", "Belts", "Wallets", "Sunglasses", "Caps & Hats"],
      },
      {
        title: "Sports & Active Wear",
        items: ["Sports Shoes", "Active T-Shirts", "Track Pants", "Tracksuits", "Sports Accessories"],
      },
      {
        title: "Innerwear & Sleepwear",
        items: ["Briefs & Trunks", "Boxers", "Vests", "Sleepwear", "Thermals"],
      },
    ],
  },
  WOMEN: {
    featured: [
      { name: "New Arrivals", href: "/category/women/new-arrivals", badge: "NEW", badgeColor: "bg-primary" },
      { name: "Bestsellers", href: "/category/women/bestsellers" },
      { name: "Sale", href: "/category/women/sale", badge: "SALE", badgeColor: "bg-secondary" },
    ],
    categories: [
      {
        title: "Indian & Fusion Wear",
        items: ["Kurtas & Suits", "Sarees", "Ethnic Wear", "Leggings", "Skirts & Palazzos"],
      },
      {
        title: "Western Wear",
        items: ["Dresses", "Tops", "T-shirts", "Jeans", "Trousers", "Shorts & Skirts"],
      },
      {
        title: "Footwear",
        items: ["Flats", "Heels", "Boots", "Sports Shoes", "Sandals"],
      },
      {
        title: "Lingerie & Sleepwear",
        items: ["Bra", "Briefs", "Shapewear", "Sleepwear", "Swimwear"],
      },
      {
        title: "Beauty & Personal Care",
        items: ["Makeup", "Skincare", "Fragrances", "Hair Care", "Bath & Body"],
      },
      {
        title: "Bags & Accessories",
        items: ["Handbags", "Wallets", "Jewellery", "Sunglasses", "Watches"],
      },
    ],
  },
  KIDS: {
    featured: [
      { name: "New Arrivals", href: "/category/kids/new-arrivals", badge: "NEW", badgeColor: "bg-primary" },
      { name: "Back to School", href: "/category/kids/back-to-school" },
      { name: "Sale", href: "/category/kids/sale", badge: "SALE", badgeColor: "bg-secondary" },
    ],
    categories: [
      {
        title: "Boys Clothing",
        items: ["T-Shirts", "Shirts", "Jeans", "Shorts", "Ethnic Wear", "Jackets"],
      },
      {
        title: "Girls Clothing",
        items: ["Dresses", "Tops", "Skirts", "Jeans", "Ethnic Wear", "Jackets"],
      },
      {
        title: "Footwear",
        items: ["Casual Shoes", "Sports Shoes", "Sandals", "School Shoes"],
      },
      {
        title: "Baby & Infants",
        items: ["Bodysuits", "Rompers", "Baby Care", "Toys"],
      },
      {
        title: "Accessories",
        items: ["Bags", "Watches", "Hair Accessories", "Sunglasses"],
      },
      {
        title: "Toys & Games",
        items: ["Educational Toys", "Action Figures", "Soft Toys", "Board Games"],
      },
    ],
  },
  HOME: {
    featured: [
      { name: "New Collection", href: "/category/home/new-collection", badge: "NEW", badgeColor: "bg-primary" },
      { name: "Bestsellers", href: "/category/home/bestsellers" },
      { name: "Sale", href: "/category/home/sale", badge: "SALE", badgeColor: "bg-secondary" },
    ],
    categories: [
      {
        title: "Bed & Bath",
        items: ["Bedsheets", "Pillows", "Blankets", "Bath Towels", "Shower Curtains"],
      },
      {
        title: "Kitchen & Dining",
        items: ["Dinnerware", "Cookware", "Kitchen Tools", "Storage"],
      },
      {
        title: "Home Décor",
        items: ["Wall Art", "Candles", "Vases", "Mirrors", "Plants"],
      },
      {
        title: "Furniture",
        items: ["Chairs", "Tables", "Storage", "Lighting"],
      },
      {
        title: "Lighting",
        items: ["Table Lamps", "Floor Lamps", "Ceiling Lights", "String Lights"],
      },
      {
        title: "Storage & Organization",
        items: ["Baskets", "Boxes", "Organizers", "Hangers"],
      },
    ],
  },
  BEAUTY: {
    featured: [
      { name: "New Launches", href: "/category/beauty/new-launches", badge: "NEW", badgeColor: "bg-primary" },
      { name: "Bestsellers", href: "/category/beauty/bestsellers" },
      { name: "Sale", href: "/category/beauty/sale", badge: "SALE", badgeColor: "bg-secondary" },
    ],
    categories: [
      {
        title: "Makeup",
        items: ["Lipstick", "Foundation", "Mascara", "Eyeliner", "Eyeshadow", "Nail Polish"],
      },
      {
        title: "Skincare",
        items: ["Face Wash", "Moisturizer", "Serum", "Sunscreen", "Face Masks"],
      },
      {
        title: "Hair Care",
        items: ["Shampoo", "Conditioner", "Hair Oil", "Hair Styling", "Hair Tools"],
      },
      {
        title: "Fragrances",
        items: ["Perfumes", "Deodorants", "Body Mist", "Gift Sets"],
      },
      {
        title: "Bath & Body",
        items: ["Body Wash", "Body Lotion", "Body Scrub", "Hand Care"],
      },
      {
        title: "Men's Grooming",
        items: ["Beard Care", "Shaving", "Hair Styling", "Body Care"],
      },
    ],
  },
  GENZ: {
    featured: [
      { name: "Trending Now", href: "/category/genz/trending", badge: "HOT", badgeColor: "bg-primary" },
      { name: "Viral Products", href: "/category/genz/viral" },
      { name: "Limited Edition", href: "/category/genz/limited", badge: "LIMITED", badgeColor: "bg-secondary" },
    ],
    categories: [
      {
        title: "Streetwear",
        items: ["Graphic Tees", "Oversized Hoodies", "Cargo Pants", "Bucket Hats"],
      },
      {
        title: "Y2K Fashion",
        items: ["Crop Tops", "Low-rise Jeans", "Platform Shoes", "Metallic Accessories"],
      },
      {
        title: "Tech & Gadgets",
        items: ["Phone Cases", "Wireless Earbuds", "LED Lights", "Ring Lights"],
      },
      {
        title: "Room Aesthetic",
        items: ["Tapestries", "Neon Signs", "Plushies", "Desk Accessories"],
      },
      {
        title: "Beauty & Self-Care",
        items: ["Skincare Sets", "Lip Glosses", "Face Gems", "Hair Accessories"],
      },
      {
        title: "Lifestyle",
        items: ["Journals", "Stickers", "Pins & Patches", "Tote Bags"],
      },
    ],
  },
  STUDIO: {
    featured: [
      { name: "New Designers", href: "/category/studio/new-designers", badge: "NEW", badgeColor: "bg-primary" },
      { name: "Exclusive Pieces", href: "/category/studio/exclusive" },
      { name: "Limited Collection", href: "/category/studio/limited", badge: "EXCLUSIVE", badgeColor: "bg-secondary" },
    ],
    categories: [
      {
        title: "Designer Wear",
        items: ["Couture Dresses", "Designer Suits", "Statement Pieces", "Runway Collection"],
      },
      {
        title: "Luxury Accessories",
        items: ["Designer Bags", "Fine Jewelry", "Luxury Watches", "Silk Scarves"],
      },
      {
        title: "Artisan Crafts",
        items: ["Handwoven Textiles", "Embroidered Pieces", "Traditional Crafts"],
      },
      {
        title: "Featured Designers",
        items: ["Sabyasachi", "Manish Malhotra", "Tarun Tahiliani", "Anita Dongre"],
      },
    ],
  },
}

export function MegaMenuNew({ category, isOpen, onClose }: MegaMenuNewProps) {
  const [activeColumn, setActiveColumn] = useState<string | null>(null)
  const isMobile = useIsMobile()
  const categoryData = subcategories[category as keyof typeof subcategories]

  useEffect(() => {
    if (isOpen && isMobile) {
      document.body.style.overflow = "hidden"
    } else {
      document.body.style.overflow = "unset"
    }

    return () => {
      document.body.style.overflow = "unset"
    }
  }, [isOpen, isMobile])

  if (!categoryData) return null

  // Mobile view
  if (isMobile) {
    return (
      <div
        className={`fixed inset-0 z-50 bg-background transition-transform duration-300 ${
          isOpen ? "translate-x-0" : "translate-x-full"
        }`}
      >
        <div className="flex items-center justify-between p-4 border-b border-accent bg-cream">
          <h2 className="text-lg font-semibold text-primary">{category}</h2>
          <Button variant="ghost" size="icon" onClick={onClose} className="text-primary">
            <X className="h-5 w-5" />
          </Button>
        </div>

        <div className="flex-1 overflow-auto p-4">
          {/* Featured Section */}
          <div className="mb-6 p-4 bg-accent/30 rounded-lg">
            <h3 className="font-semibold text-primary mb-3">Featured</h3>
            <div className="space-y-2">
              {categoryData.featured.map((item, index) => (
                <Link
                  key={index}
                  href={item.href}
                  className="flex items-center justify-between p-3 rounded-md hover:bg-accent/50 transition-colors bg-white"
                  onClick={onClose}
                >
                  <span className="text-sm font-medium">{item.name}</span>
                  <div className="flex items-center gap-2">
                    {item.badge && (
                      <span className={`text-xs text-white px-2 py-1 rounded ${item.badgeColor}`}>{item.badge}</span>
                    )}
                    <ChevronRight className="h-4 w-4 text-muted-foreground" />
                  </div>
                </Link>
              ))}
            </div>
          </div>

          {/* Categories */}
          <div className="space-y-3">
            {categoryData.categories.map((section, index) => (
              <div key={index} className="border border-accent rounded-lg overflow-hidden bg-white">
                <button
                  className="w-full p-4 text-left hover:bg-accent/30 transition-colors"
                  onClick={() => setActiveColumn(activeColumn === section.title ? null : section.title)}
                >
                  <div className="flex items-center justify-between">
                    <h3 className="font-semibold text-primary">{section.title}</h3>
                    <ChevronRight
                      className={`h-4 w-4 transition-transform ${activeColumn === section.title ? "rotate-90" : ""}`}
                    />
                  </div>
                </button>
                {activeColumn === section.title && (
                  <div className="p-4 bg-cream/50 border-t border-accent">
                    <div className="grid grid-cols-2 gap-2">
                      {section.items.map((item, itemIndex) => (
                        <Link
                          key={itemIndex}
                          href={`/category/${category.toLowerCase()}/${section.title
                            .toLowerCase()
                            .replace(/\s+/g, "-")}/${item.toLowerCase().replace(/\s+/g, "-")}`}
                          className="text-sm p-2 rounded hover:bg-accent/30 transition-colors"
                          onClick={onClose}
                        >
                          {item}
                        </Link>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </div>
    )
  }

  // Desktop view with fixed width and proper positioning
  return (
    <div className="absolute left-0 top-full z-50 w-screen bg-white shadow-2xl border-t-4 border-primary">
      <div className="max-w-7xl mx-auto px-8 py-8">
        {/* Featured Section */}
        <div className="mb-8 p-6 bg-gradient-to-r from-cream to-accent rounded-xl">
          <h3 className="font-bold text-primary mb-4 text-lg">Featured</h3>
          <div className="flex flex-wrap gap-4">
            {categoryData.featured.map((item, index) => (
              <Link
                key={index}
                href={item.href}
                className="group flex items-center gap-3 px-6 py-3 bg-white rounded-lg hover:bg-primary hover:text-white transition-all duration-200 shadow-md border border-accent/50 min-w-fit"
              >
                <span className="font-medium text-sm whitespace-nowrap">{item.name}</span>
                {item.badge && (
                  <span
                    className={`text-xs text-white px-2 py-1 rounded ${item.badgeColor} group-hover:bg-white group-hover:text-primary transition-colors`}
                  >
                    {item.badge}
                  </span>
                )}
              </Link>
            ))}
          </div>
        </div>

        {/* Categories Grid with fixed layout */}
        <div className="grid grid-cols-3 gap-8">
          {categoryData.categories.map((section, index) => (
            <div
              key={index}
              className="bg-white rounded-lg p-6 border border-accent/30 hover:shadow-lg transition-shadow"
            >
              <h3 className="font-bold text-primary text-base mb-4 border-b border-accent pb-2">{section.title}</h3>
              <ul className="space-y-2">
                {section.items.map((item, itemIndex) => (
                  <li key={itemIndex}>
                    <Link
                      href={`/category/${category.toLowerCase()}/${section.title
                        .toLowerCase()
                        .replace(/\s+/g, "-")}/${item.toLowerCase().replace(/\s+/g, "-")}`}
                      className="text-sm text-gray-700 hover:text-primary transition-colors duration-200 hover:underline block py-1 hover:pl-2 transition-all"
                    >
                      {item}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}
