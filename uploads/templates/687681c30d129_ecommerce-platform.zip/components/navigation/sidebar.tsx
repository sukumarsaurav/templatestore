"use client"

import Link from "next/link"
import { usePathname } from "next/navigation"
import { ChevronRight, Home, Search, ShoppingBag, X } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Separator } from "@/components/ui/separator"
import { cn } from "@/lib/utils"
import { useAuth } from "@/context/auth-context"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion"

interface SidebarProps {
  onClose: () => void
}

// Mock data for subcategories - same structure as in mega-menu.tsx
const subcategories = {
  Men: [
    {
      title: "Clothing",
      items: ["T-Shirts", "Shirts", "Jeans", "Trousers", "Jackets", "Hoodies", "Sweaters", "Activewear"],
    },
    {
      title: "Footwear",
      items: ["Sneakers", "Formal Shoes", "Boots", "Sandals", "Slippers"],
    },
    {
      title: "Accessories",
      items: ["Watches", "Belts", "Wallets", "Ties", "Sunglasses", "Hats", "Socks"],
    },
    {
      title: "Collections",
      items: ["New Arrivals", "Bestsellers", "Summer Collection", "Winter Collection", "Workwear", "Casual"],
    },
  ],
  Women: [
    {
      title: "Clothing",
      items: ["Dresses", "Tops", "Blouses", "Skirts", "Jeans", "Trousers", "Jackets", "Activewear"],
    },
    {
      title: "Footwear",
      items: ["Heels", "Flats", "Boots", "Sneakers", "Sandals"],
    },
    {
      title: "Accessories",
      items: ["Jewelry", "Bags", "Scarves", "Belts", "Sunglasses", "Hats"],
    },
    {
      title: "Collections",
      items: ["New Arrivals", "Bestsellers", "Summer Collection", "Winter Collection", "Office Wear", "Party Wear"],
    },
  ],
  Kids: [
    {
      title: "Boys",
      items: ["T-Shirts", "Shirts", "Jeans", "Trousers", "Jackets", "Activewear"],
    },
    {
      title: "Girls",
      items: ["Dresses", "Tops", "Skirts", "Jeans", "Jackets", "Activewear"],
    },
    {
      title: "Footwear",
      items: ["Sneakers", "Sandals", "Boots", "School Shoes"],
    },
    {
      title: "Age Groups",
      items: ["Infants (0-2 years)", "Toddlers (2-4 years)", "Kids (4-8 years)", "Pre-teens (8-12 years)"],
    },
  ],
  Home: [
    {
      title: "Living Room",
      items: ["Sofas", "Coffee Tables", "TV Units", "Rugs", "Curtains", "Cushions"],
    },
    {
      title: "Bedroom",
      items: ["Bed Sheets", "Pillows", "Duvets", "Blankets", "Mattresses"],
    },
    {
      title: "Kitchen & Dining",
      items: ["Cookware", "Tableware", "Cutlery", "Glassware", "Kitchen Textiles"],
    },
    {
      title: "Bathroom",
      items: ["Towels", "Bath Mats", "Shower Curtains", "Bathroom Accessories"],
    },
  ],
  Beauty: [
    {
      title: "Skincare",
      items: ["Cleansers", "Moisturizers", "Serums", "Face Masks", "Eye Care", "Sun Care"],
    },
    {
      title: "Makeup",
      items: ["Face", "Eyes", "Lips", "Nails", "Makeup Tools"],
    },
    {
      title: "Hair Care",
      items: ["Shampoo", "Conditioner", "Hair Treatments", "Styling Products", "Hair Tools"],
    },
    {
      title: "Fragrance",
      items: ["Women's Perfume", "Men's Cologne", "Gift Sets"],
    },
  ],
}

const mainCategories = [
  { name: "Men", href: "/category/men" },
  { name: "Women", href: "/category/women" },
  { name: "Kids", href: "/category/kids" },
  { name: "Home", href: "/category/home" },
  { name: "Beauty", href: "/category/beauty" },
]

export function Sidebar({ onClose }: SidebarProps) {
  const pathname = usePathname()
  const { user, logout } = useAuth()

  return (
    <div className="flex flex-col h-full bg-background">
      <div className="flex items-center justify-between p-4 border-b border-accent">
        <Link href="/" className="font-bold text-xl text-primary" onClick={onClose}>
          Fashion Store
        </Link>
        <Button variant="ghost" size="icon" onClick={onClose} className="text-primary">
          <X className="h-5 w-5" />
        </Button>
      </div>

      <div className="p-4">
        <div className="relative">
          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input type="search" placeholder="Search products..." className="w-full pl-8 border-accent" />
        </div>
      </div>

      <div className="flex-1 overflow-auto">
        <div className="p-4">
          <Accordion type="single" collapsible className="w-full">
            {mainCategories.map((category) => (
              <AccordionItem key={category.name} value={category.name} className="border-accent">
                <AccordionTrigger className="hover:text-primary">{category.name}</AccordionTrigger>
                <AccordionContent>
                  {subcategories[category.name as keyof typeof subcategories]?.map((section, index) => (
                    <div key={index} className="mb-4">
                      <h4 className="font-medium text-primary mb-2">{section.title}</h4>
                      <ul className="space-y-1 pl-2">
                        {section.items.map((item, itemIndex) => (
                          <li key={itemIndex}>
                            <Link
                              href={`/category/${category.name.toLowerCase()}/${section.title.toLowerCase()}/${item.toLowerCase().replace(/\s+/g, "-")}`}
                              className="text-sm hover:text-primary flex items-center py-1"
                              onClick={onClose}
                            >
                              {item}
                              <ChevronRight className="ml-1 h-3 w-3 opacity-50" />
                            </Link>
                          </li>
                        ))}
                      </ul>
                    </div>
                  ))}
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>

          <Separator className="my-4 bg-accent" />

          <nav className="space-y-2">
            <Link
              href="/"
              className={cn(
                "flex items-center gap-2 rounded-md px-3 py-2 text-sm font-medium transition-colors hover:bg-accent",
                pathname === "/" ? "bg-primary text-primary-foreground" : "",
              )}
              onClick={onClose}
            >
              <Home className="h-4 w-4" />
              Home
            </Link>
            <Link
              href="/products"
              className={cn(
                "flex items-center gap-2 rounded-md px-3 py-2 text-sm font-medium transition-colors hover:bg-accent",
                pathname === "/products" ? "bg-primary text-primary-foreground" : "",
              )}
              onClick={onClose}
            >
              <ShoppingBag className="h-4 w-4" />
              All Products
            </Link>
          </nav>
        </div>
      </div>

      <div className="p-4 border-t border-accent">
        {user ? (
          <div className="space-y-3">
            <div className="flex items-center gap-3">
              <Avatar className="h-10 w-10 bg-primary/10">
                <AvatarImage src="/placeholder-user.jpg" alt={user.firstName} />
                <AvatarFallback className="text-primary">{user.firstName.charAt(0)}</AvatarFallback>
              </Avatar>
              <div>
                <p className="font-medium">{`${user.firstName} ${user.lastName}`}</p>
                <p className="text-sm text-muted-foreground">{user.email}</p>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-2">
              <Button variant="outline" asChild className="border-accent hover:bg-accent">
                <Link href="/account" onClick={onClose}>
                  My Account
                </Link>
              </Button>
              <Button
                variant="outline"
                className="border-accent hover:bg-accent"
                onClick={() => {
                  logout()
                  onClose()
                }}
              >
                Sign Out
              </Button>
            </div>
          </div>
        ) : (
          <div className="grid grid-cols-2 gap-2">
            <Button variant="outline" asChild className="border-accent hover:bg-accent">
              <Link href="/login" onClick={onClose}>
                Sign In
              </Link>
            </Button>
            <Button asChild>
              <Link href="/register" onClick={onClose}>
                Register
              </Link>
            </Button>
          </div>
        )}
      </div>
    </div>
  )
}
