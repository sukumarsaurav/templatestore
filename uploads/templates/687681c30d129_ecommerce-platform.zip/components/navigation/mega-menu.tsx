import Link from "next/link"
import { ChevronRight } from "lucide-react"

interface MegaMenuProps {
  category: string
}

// Mock data for subcategories
const subcategories = {
  Men: [
    {
      title: "Clothing",
      items: ["T-Shirts", "Shirts", "Jeans", "Trousers", "Jackets", "Hoodies", "Sweaters", "Activewear"],
    },
    {
      title: "Footwear",
      items: ["Sneakers", "Formal Shoes", "Boots", "Sandals", "Slippers"],
    },
    {
      title: "Accessories",
      items: ["Watches", "Belts", "Wallets", "Ties", "Sunglasses", "Hats", "Socks"],
    },
    {
      title: "Collections",
      items: ["New Arrivals", "Bestsellers", "Summer Collection", "Winter Collection", "Workwear", "Casual"],
    },
  ],
  Women: [
    {
      title: "Clothing",
      items: ["Dresses", "Tops", "Blouses", "Skirts", "Jeans", "Trousers", "Jackets", "Activewear"],
    },
    {
      title: "Footwear",
      items: ["Heels", "Flats", "Boots", "Sneakers", "Sandals"],
    },
    {
      title: "Accessories",
      items: ["Jewelry", "Bags", "Scarves", "Belts", "Sunglasses", "Hats"],
    },
    {
      title: "Collections",
      items: ["New Arrivals", "Bestsellers", "Summer Collection", "Winter Collection", "Office Wear", "Party Wear"],
    },
  ],
  Kids: [
    {
      title: "Boys",
      items: ["T-Shirts", "Shirts", "Jeans", "Trousers", "Jackets", "Activewear"],
    },
    {
      title: "Girls",
      items: ["Dresses", "Tops", "Skirts", "Jeans", "Jackets", "Activewear"],
    },
    {
      title: "Footwear",
      items: ["Sneakers", "Sandals", "Boots", "School Shoes"],
    },
    {
      title: "Age Groups",
      items: ["Infants (0-2 years)", "Toddlers (2-4 years)", "Kids (4-8 years)", "Pre-teens (8-12 years)"],
    },
  ],
  Home: [
    {
      title: "Living Room",
      items: ["Sofas", "Coffee Tables", "TV Units", "Rugs", "Curtains", "Cushions"],
    },
    {
      title: "Bedroom",
      items: ["Bed Sheets", "Pillows", "Duvets", "Blankets", "Mattresses"],
    },
    {
      title: "Kitchen & Dining",
      items: ["Cookware", "Tableware", "Cutlery", "Glassware", "Kitchen Textiles"],
    },
    {
      title: "Bathroom",
      items: ["Towels", "Bath Mats", "Shower Curtains", "Bathroom Accessories"],
    },
  ],
  Beauty: [
    {
      title: "Skincare",
      items: ["Cleansers", "Moisturizers", "Serums", "Face Masks", "Eye Care", "Sun Care"],
    },
    {
      title: "Makeup",
      items: ["Face", "Eyes", "Lips", "Nails", "Makeup Tools"],
    },
    {
      title: "Hair Care",
      items: ["Shampoo", "Conditioner", "Hair Treatments", "Styling Products", "Hair Tools"],
    },
    {
      title: "Fragrance",
      items: ["Women's Perfume", "Men's Cologne", "Gift Sets"],
    },
  ],
}

export function MegaMenu({ category }: MegaMenuProps) {
  const categoryData = subcategories[category as keyof typeof subcategories] || []

  return (
    <div className="mega-menu absolute left-0 top-full z-50 w-screen bg-background shadow-lg rounded-b-lg border-t border-accent">
      <div className="container px-4 md:px-6 py-6">
        <div className="grid grid-cols-4 gap-8">
          {categoryData.map((section, index) => (
            <div key={index} className="space-y-3">
              <h3 className="font-semibold text-primary">{section.title}</h3>
              <ul className="space-y-2">
                {section.items.map((item, itemIndex) => (
                  <li key={itemIndex}>
                    <Link
                      href={`/category/${category.toLowerCase()}/${section.title.toLowerCase()}/${item.toLowerCase().replace(/\s+/g, "-")}`}
                      className="text-sm hover:text-primary flex items-center"
                    >
                      {item}
                      <ChevronRight className="ml-1 h-3 w-3 opacity-50" />
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
        <div className="mt-8 pt-6 border-t border-accent">
          <div className="flex justify-between items-center">
            <h3 className="font-semibold text-primary">Featured {category} Collections</h3>
            <Link href={`/category/${category.toLowerCase()}`} className="text-sm text-primary hover:underline">
              View All {category} Products
            </Link>
          </div>
        </div>
      </div>
    </div>
  )
}
