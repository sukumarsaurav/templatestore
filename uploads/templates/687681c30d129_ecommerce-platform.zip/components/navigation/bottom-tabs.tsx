"use client"

import { useState } from "react"
import Link from "next/link"
import { usePathname } from "next/navigation"
import { Home, Search, ShoppingBag, User, Menu } from "lucide-react"
import { cn } from "@/lib/utils"
import { useCart } from "@/context/cart-context"
import { Badge } from "@/components/ui/badge"
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet"
import { Button } from "@/components/ui/button"
import { Sidebar } from "@/components/navigation/sidebar"

export function BottomTabs() {
  const pathname = usePathname()
  const { cartItems } = useCart()
  const [isSidebarOpen, setIsSidebarOpen] = useState(false)

  const tabs = [
    { name: "Home", href: "/", icon: Home },
    { name: "Search", href: "/search", icon: Search },
    { name: "Cart", href: "/cart", icon: ShoppingBag, badge: cartItems.length > 0 ? cartItems.length : null },
    { name: "Account", href: "/account", icon: User },
    { name: "Menu", href: "#", icon: Menu, action: () => setIsSidebarOpen(true) },
  ]

  const activeTab = tabs.findIndex(
    (tab) => tab.href !== "#" && (pathname === tab.href || pathname.startsWith(tab.href + "/")),
  )

  return (
    <>
      <div className="fixed bottom-0 left-0 right-0 z-50 bg-background border-t border-accent md:hidden">
        <div className="flex justify-around items-center h-16 px-2">
          {tabs.map((tab, index) => (
            <div key={tab.name} className="flex-1 flex justify-center">
              {tab.action ? (
                <Sheet open={isSidebarOpen} onOpenChange={setIsSidebarOpen}>
                  <SheetTrigger asChild>
                    <Button
                      variant="ghost"
                      className={cn(
                        "flex flex-col items-center justify-center h-full w-full rounded-none",
                        index === activeTab ? "text-primary" : "text-muted-foreground",
                      )}
                    >
                      <tab.icon className="h-5 w-5" />
                      <span className="text-xs mt-1">{tab.name}</span>
                    </Button>
                  </SheetTrigger>
                  <SheetContent side="left" className="w-[300px] sm:w-[350px] p-0">
                    <Sidebar onClose={() => setIsSidebarOpen(false)} />
                  </SheetContent>
                </Sheet>
              ) : (
                <Link
                  href={tab.href}
                  className={cn(
                    "flex flex-col items-center justify-center h-full w-full",
                    index === activeTab ? "text-primary" : "text-muted-foreground",
                  )}
                >
                  <div className="relative">
                    <tab.icon className="h-5 w-5" />
                    {tab.badge && (
                      <Badge className="absolute -right-2 -top-2 h-4 w-4 p-0 flex items-center justify-center text-[10px] bg-secondary text-white">
                        {tab.badge}
                      </Badge>
                    )}
                  </div>
                  <span className="text-xs mt-1">{tab.name}</span>
                </Link>
              )}
            </div>
          ))}
          {activeTab >= 0 && (
            <div
              className="bottom-tab-indicator"
              style={{
                width: `${100 / tabs.length}%`,
                transform: `translateX(${activeTab * 100}%)`,
              }}
            />
          )}
        </div>
      </div>
      <div className="pb-16 md:pb-0">
        {/* This div adds padding at the bottom to prevent content from being hidden behind the bottom tabs */}
      </div>
    </>
  )
}
