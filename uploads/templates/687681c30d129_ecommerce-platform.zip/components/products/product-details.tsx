"use client"

import { useState } from "react"
import Image from "next/image"
import { Heart, Minus, Plus, Share2, Star } from "lucide-react"
import { Button } from "@/components/ui/button"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Label } from "@/components/ui/label"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { useCart } from "@/context/cart-context"
import { useToast } from "@/hooks/use-toast"

// Mock product data - in a real app, this would come from an API
const product = {
  id: 1,
  name: "Cotton T-Shirt",
  slug: "cotton-t-shirt",
  price: 29.99,
  description:
    "A comfortable cotton t-shirt perfect for everyday wear. Made from 100% organic cotton, this t-shirt is both stylish and sustainable.",
  features: [
    "100% organic cotton",
    "Comfortable fit",
    "Machine washable",
    "Available in multiple colors",
    "Sustainable production",
  ],
  specifications: {
    material: "100% Organic Cotton",
    fit: "Regular",
    care: "Machine wash cold, tumble dry low",
    origin: "Made in Portugal",
  },
  colors: [
    { id: "black", name: "Black", value: "#000000" },
    { id: "white", name: "White", value: "#ffffff" },
    { id: "blue", name: "Blue", value: "#0000ff" },
  ],
  sizes: ["XS", "S", "M", "L", "XL"],
  images: [
    "/placeholder.svg?height=600&width=500",
    "/placeholder.svg?height=600&width=500",
    "/placeholder.svg?height=600&width=500",
    "/placeholder.svg?height=600&width=500",
  ],
  rating: 4.5,
  reviewCount: 128,
}

interface ProductDetailsProps {
  slug: string
}

export function ProductDetails({ slug }: ProductDetailsProps) {
  const [selectedColor, setSelectedColor] = useState(product.colors[0].id)
  const [selectedSize, setSelectedSize] = useState(product.sizes[2])
  const [quantity, setQuantity] = useState(1)
  const [activeImage, setActiveImage] = useState(0)
  const [isWishlisted, setIsWishlisted] = useState(false)

  const { addToCart } = useCart()
  const { toast } = useToast()

  const incrementQuantity = () => {
    setQuantity((prev) => prev + 1)
  }

  const decrementQuantity = () => {
    setQuantity((prev) => (prev > 1 ? prev - 1 : 1))
  }

  const handleAddToCart = () => {
    addToCart({
      id: product.id,
      name: product.name,
      price: product.price,
      image: product.images[0],
      quantity,
      color: product.colors.find((c) => c.id === selectedColor)?.name,
      size: selectedSize,
    })
    toast({
      title: "Added to cart",
      description: `${product.name} has been added to your cart`,
    })
  }

  const toggleWishlist = () => {
    setIsWishlisted(!isWishlisted)
    toast({
      title: isWishlisted ? "Removed from wishlist" : "Added to wishlist",
      description: `${product.name} has been ${isWishlisted ? "removed from" : "added to"} your wishlist`,
    })
  }

  return (
    <div className="grid md:grid-cols-2 gap-8 mb-16">
      <div className="space-y-4">
        <div className="aspect-square overflow-hidden rounded-lg border">
          <Image
            src={product.images[activeImage] || "/placeholder.svg"}
            alt={product.name}
            width={500}
            height={600}
            className="h-full w-full object-cover"
          />
        </div>
        <div className="flex space-x-2 overflow-auto pb-2">
          {product.images.map((image, index) => (
            <button
              key={index}
              className={`relative h-20 w-20 flex-shrink-0 overflow-hidden rounded-md border ${
                activeImage === index ? "ring-2 ring-primary" : ""
              }`}
              onClick={() => setActiveImage(index)}
            >
              <Image
                src={image || "/placeholder.svg"}
                alt={`${product.name} - Image ${index + 1}`}
                width={80}
                height={80}
                className="h-full w-full object-cover"
              />
            </button>
          ))}
        </div>
      </div>
      <div className="space-y-6">
        <div>
          <h1 className="text-2xl md:text-3xl font-bold">{product.name}</h1>
          <div className="flex items-center mt-2 space-x-2">
            <div className="flex">
              {[...Array(5)].map((_, i) => (
                <Star
                  key={i}
                  className={`h-4 w-4 ${
                    i < Math.floor(product.rating)
                      ? "text-yellow-400 fill-yellow-400"
                      : i < product.rating
                        ? "text-yellow-400 fill-yellow-400 half"
                        : "text-gray-300"
                  }`}
                />
              ))}
            </div>
            <span className="text-sm text-muted-foreground">
              {product.rating} ({product.reviewCount} reviews)
            </span>
          </div>
          <p className="text-2xl font-bold mt-2">${product.price.toFixed(2)}</p>
        </div>
        <p className="text-muted-foreground">{product.description}</p>
        <div className="space-y-4">
          <div>
            <h3 className="font-medium mb-2">Color</h3>
            <RadioGroup value={selectedColor} onValueChange={setSelectedColor} className="flex space-x-2">
              {product.colors.map((color) => (
                <div key={color.id} className="flex items-center space-x-1">
                  <RadioGroupItem id={`color-${color.id}`} value={color.id} className="sr-only" />
                  <Label
                    htmlFor={`color-${color.id}`}
                    className="relative flex h-8 w-8 cursor-pointer items-center justify-center rounded-full"
                  >
                    <span
                      className={`absolute inset-0 rounded-full ${
                        selectedColor === color.id ? "ring-2 ring-primary" : ""
                      }`}
                      style={{ backgroundColor: color.value }}
                    />
                  </Label>
                </div>
              ))}
            </RadioGroup>
          </div>
          <div>
            <h3 className="font-medium mb-2">Size</h3>
            <RadioGroup value={selectedSize} onValueChange={setSelectedSize} className="flex flex-wrap gap-2">
              {product.sizes.map((size) => (
                <div key={size} className="flex items-center space-x-1">
                  <RadioGroupItem id={`size-${size}`} value={size} className="sr-only" />
                  <Label
                    htmlFor={`size-${size}`}
                    className={`flex h-9 w-9 cursor-pointer items-center justify-center rounded-md border ${
                      selectedSize === size
                        ? "border-primary bg-primary text-primary-foreground"
                        : "border-input hover:bg-muted"
                    }`}
                  >
                    {size}
                  </Label>
                </div>
              ))}
            </RadioGroup>
          </div>
          <div>
            <h3 className="font-medium mb-2">Quantity</h3>
            <div className="flex items-center space-x-2">
              <Button variant="outline" size="icon" onClick={decrementQuantity} disabled={quantity <= 1}>
                <Minus className="h-4 w-4" />
              </Button>
              <span className="w-8 text-center">{quantity}</span>
              <Button variant="outline" size="icon" onClick={incrementQuantity}>
                <Plus className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </div>
        <div className="flex flex-col sm:flex-row gap-3">
          <Button className="flex-1" onClick={handleAddToCart}>
            Add to Cart
          </Button>
          <Button variant="outline" size="icon" onClick={toggleWishlist}>
            <Heart className={`h-5 w-5 ${isWishlisted ? "fill-red-500 text-red-500" : ""}`} />
          </Button>
          <Button variant="outline" size="icon">
            <Share2 className="h-5 w-5" />
          </Button>
        </div>
        <Tabs defaultValue="description">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="description">Description</TabsTrigger>
            <TabsTrigger value="features">Features</TabsTrigger>
            <TabsTrigger value="specifications">Specifications</TabsTrigger>
          </TabsList>
          <TabsContent value="description" className="pt-4">
            <p className="text-sm text-muted-foreground">{product.description}</p>
          </TabsContent>
          <TabsContent value="features" className="pt-4">
            <ul className="list-disc pl-5 space-y-1 text-sm text-muted-foreground">
              {product.features.map((feature, index) => (
                <li key={index}>{feature}</li>
              ))}
            </ul>
          </TabsContent>
          <TabsContent value="specifications" className="pt-4">
            <div className="space-y-2 text-sm">
              {Object.entries(product.specifications).map(([key, value]) => (
                <div key={key} className="grid grid-cols-2">
                  <span className="font-medium capitalize">{key}</span>
                  <span className="text-muted-foreground">{value}</span>
                </div>
              ))}
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
