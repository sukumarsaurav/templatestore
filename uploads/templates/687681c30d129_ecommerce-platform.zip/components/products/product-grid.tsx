"use client"

import { useState } from "react"
import Link from "next/link"
import Image from "next/image"
import { Heart } from "lucide-react"
import { Button } from "@/components/ui/button"
import { useCart } from "@/context/cart-context"
import { useToast } from "@/hooks/use-toast"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

const products = [
  {
    id: 1,
    name: "Cotton T-Shirt",
    price: 29.99,
    image: "/placeholder.svg?height=400&width=300",
    slug: "cotton-t-shirt",
    category: "men",
  },
  {
    id: 2,
    name: "Slim Fit Jeans",
    price: 59.99,
    image: "/placeholder.svg?height=400&width=300",
    slug: "slim-fit-jeans",
    category: "men",
  },
  {
    id: 3,
    name: "Summer Dress",
    price: 49.99,
    image: "/placeholder.svg?height=400&width=300",
    slug: "summer-dress",
    category: "women",
  },
  {
    id: 4,
    name: "Leather Jacket",
    price: 199.99,
    image: "/placeholder.svg?height=400&width=300",
    slug: "leather-jacket",
    category: "women",
  },
  {
    id: 5,
    name: "Floral Print Blouse",
    price: 39.99,
    image: "/placeholder.svg?height=400&width=300",
    slug: "floral-print-blouse",
    category: "women",
  },
  {
    id: 6,
    name: "Casual Sneakers",
    price: 79.99,
    image: "/placeholder.svg?height=400&width=300",
    slug: "casual-sneakers",
    category: "men",
  },
  {
    id: 7,
    name: "Denim Shorts",
    price: 34.99,
    image: "/placeholder.svg?height=400&width=300",
    slug: "denim-shorts",
    category: "women",
  },
  {
    id: 8,
    name: "Striped Polo Shirt",
    price: 44.99,
    image: "/placeholder.svg?height=400&width=300",
    slug: "striped-polo-shirt",
    category: "men",
  },
]

export function ProductGrid() {
  const { addToCart } = useCart()
  const { toast } = useToast()
  const [wishlist, setWishlist] = useState<number[]>([])
  const [sortOption, setSortOption] = useState("featured")

  const toggleWishlist = (productId: number) => {
    if (wishlist.includes(productId)) {
      setWishlist(wishlist.filter((id) => id !== productId))
      toast({
        title: "Removed from wishlist",
        description: "The product has been removed from your wishlist",
      })
    } else {
      setWishlist([...wishlist, productId])
      toast({
        title: "Added to wishlist",
        description: "The product has been added to your wishlist",
      })
    }
  }

  const handleAddToCart = (product: any) => {
    addToCart({
      id: product.id,
      name: product.name,
      price: product.price,
      image: product.image,
      quantity: 1,
    })
    toast({
      title: "Added to cart",
      description: `${product.name} has been added to your cart`,
    })
  }

  const sortedProducts = [...products].sort((a, b) => {
    switch (sortOption) {
      case "price-low-high":
        return a.price - b.price
      case "price-high-low":
        return b.price - a.price
      case "name-a-z":
        return a.name.localeCompare(b.name)
      case "name-z-a":
        return b.name.localeCompare(a.name)
      default:
        return 0
    }
  })

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <p className="text-sm text-muted-foreground">Showing {products.length} products</p>
        <Select value={sortOption} onValueChange={setSortOption}>
          <SelectTrigger className="w-[180px] border-accent">
            <SelectValue placeholder="Sort by" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="featured">Featured</SelectItem>
            <SelectItem value="price-low-high">Price: Low to High</SelectItem>
            <SelectItem value="price-high-low">Price: High to Low</SelectItem>
            <SelectItem value="name-a-z">Name: A to Z</SelectItem>
            <SelectItem value="name-z-a">Name: Z to A</SelectItem>
          </SelectContent>
        </Select>
      </div>
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4 md:gap-6">
        {sortedProducts.map((product) => (
          <div key={product.id} className="group relative border border-accent rounded-lg overflow-hidden">
            <div className="aspect-square overflow-hidden">
              <Image
                src={product.image || "/placeholder.svg"}
                alt={product.name}
                width={300}
                height={400}
                className="h-full w-full object-cover transition-transform duration-300 group-hover:scale-105"
              />
            </div>
            <Button
              variant="ghost"
              size="icon"
              className="absolute right-2 top-2 bg-white/80 backdrop-blur-sm rounded-full text-primary"
              onClick={() => toggleWishlist(product.id)}
            >
              <Heart className={`h-5 w-5 ${wishlist.includes(product.id) ? "fill-primary text-primary" : ""}`} />
            </Button>
            <div className="p-4">
              <Link href={`/product/${product.slug}`}>
                <h3 className="font-medium text-base mb-1 group-hover:text-primary">{product.name}</h3>
              </Link>
              <p className="font-semibold text-secondary">${product.price.toFixed(2)}</p>
              <Button className="w-full mt-3 bg-primary hover:bg-secondary" onClick={() => handleAddToCart(product)}>
                Add to Cart
              </Button>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}
