import Link from "next/link"
import Image from "next/image"

const recommendedProducts = [
  {
    id: 2,
    name: "Slim Fit Jeans",
    price: 59.99,
    image: "/placeholder.svg?height=400&width=300",
    slug: "slim-fit-jeans",
  },
  {
    id: 3,
    name: "Summer Dress",
    price: 49.99,
    image: "/placeholder.svg?height=400&width=300",
    slug: "summer-dress",
  },
  {
    id: 4,
    name: "Leather Jacket",
    price: 199.99,
    image: "/placeholder.svg?height=400&width=300",
    slug: "leather-jacket",
  },
  {
    id: 5,
    name: "Floral Print Blouse",
    price: 39.99,
    image: "/placeholder.svg?height=400&width=300",
    slug: "floral-print-blouse",
  },
]

export function ProductRecommendations() {
  return (
    <section>
      <h2 className="text-2xl font-bold mb-6">You May Also Like</h2>
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 md:gap-6">
        {recommendedProducts.map((product) => (
          <div key={product.id} className="group border rounded-lg overflow-hidden">
            <div className="aspect-square overflow-hidden">
              <Image
                src={product.image || "/placeholder.svg"}
                alt={product.name}
                width={300}
                height={400}
                className="h-full w-full object-cover transition-transform duration-300 group-hover:scale-105"
              />
            </div>
            <div className="p-4">
              <Link href={`/product/${product.slug}`}>
                <h3 className="font-medium text-base mb-1 group-hover:underline">{product.name}</h3>
              </Link>
              <p className="font-semibold">${product.price.toFixed(2)}</p>
            </div>
          </div>
        ))}
      </div>
    </section>
  )
}
