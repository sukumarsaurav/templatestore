import { ProductGrid } from "@/components/products/product-grid"
import { ProductFilters } from "@/components/products/product-filters"

export default function ProductsPage() {
  return (
    <div className="container px-4 md:px-6 py-8">
      <h1 className="text-2xl font-bold tracking-tight mb-6">All Products</h1>
      <div className="grid md:grid-cols-[240px_1fr] gap-8">
        <ProductFilters />
        <ProductGrid />
      </div>
    </div>
  )
}
