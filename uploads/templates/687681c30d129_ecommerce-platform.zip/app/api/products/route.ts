import { NextResponse } from "next/server"

// Mock product data - in a real app, this would come from a database
const products = [
  {
    id: 1,
    name: "Cotton T-Shirt",
    price: 29.99,
    image: "/placeholder.svg?height=400&width=300",
    slug: "cotton-t-shirt",
    category: "men",
    description: "A comfortable cotton t-shirt perfect for everyday wear.",
    is_featured: true,
    is_new: false,
  },
  {
    id: 2,
    name: "Slim Fit Jeans",
    price: 59.99,
    image: "/placeholder.svg?height=400&width=300",
    slug: "slim-fit-jeans",
    category: "men",
    description: "Classic slim fit jeans that go with everything.",
    is_featured: true,
    is_new: false,
  },
  {
    id: 3,
    name: "Summer Dress",
    price: 49.99,
    image: "/placeholder.svg?height=400&width=300",
    slug: "summer-dress",
    category: "women",
    description: "Light and breezy summer dress for hot days.",
    is_featured: true,
    is_new: false,
  },
  {
    id: 4,
    name: "Leather Jacket",
    price: 199.99,
    image: "/placeholder.svg?height=400&width=300",
    slug: "leather-jacket",
    category: "women",
    description: "Classic leather jacket for a timeless look.",
    is_featured: true,
    is_new: false,
  },
  {
    id: 5,
    name: "Floral Print Blouse",
    price: 39.99,
    image: "/placeholder.svg?height=400&width=300",
    slug: "floral-print-blouse",
    category: "women",
    description: "Elegant floral print blouse for a feminine look.",
    is_featured: false,
    is_new: true,
  },
  {
    id: 6,
    name: "Casual Sneakers",
    price: 79.99,
    image: "/placeholder.svg?height=400&width=300",
    slug: "casual-sneakers",
    category: "men",
    description: "Comfortable casual sneakers for everyday wear.",
    is_featured: false,
    is_new: true,
  },
  {
    id: 7,
    name: "Denim Shorts",
    price: 34.99,
    image: "/placeholder.svg?height=400&width=300",
    slug: "denim-shorts",
    category: "women",
    description: "Classic denim shorts for summer days.",
    is_featured: false,
    is_new: true,
  },
  {
    id: 8,
    name: "Striped Polo Shirt",
    price: 44.99,
    image: "/placeholder.svg?height=400&width=300",
    slug: "striped-polo-shirt",
    category: "men",
    description: "Classic striped polo shirt for a smart casual look.",
    is_featured: false,
    is_new: true,
  },
]

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url)
  const category = searchParams.get("category")
  const featured = searchParams.get("featured")
  const newArrival = searchParams.get("new")

  let filteredProducts = [...products]

  if (category) {
    filteredProducts = filteredProducts.filter((product) => product.category === category)
  }

  if (featured === "true") {
    filteredProducts = filteredProducts.filter((product) => product.is_featured)
  }

  if (newArrival === "true") {
    filteredProducts = filteredProducts.filter((product) => product.is_new)
  }

  return NextResponse.json(filteredProducts)
}
