import { FeaturedProducts } from "@/components/home/featured-products"
import { HeroSection } from "@/components/home/hero-section"
import { CategoryShowcase } from "@/components/home/category-showcase"
import { NewArrivals } from "@/components/home/new-arrivals"
import { PromoSection } from "@/components/home/promo-section"
import { Newsletter } from "@/components/home/newsletter"

export default function Home() {
  return (
    <div className="space-y-10 pb-10">
      <HeroSection />
      <CategoryShowcase />
      <FeaturedProducts />
      <PromoSection />
      <NewArrivals />
      <Newsletter />
    </div>
  )
}
