import { LoginForm } from "@/components/auth/login-form"

export default function LoginPage() {
  return (
    <div className="container px-4 md:px-6 py-8 md:py-12 max-w-md mx-auto">
      <div className="text-center mb-8">
        <h1 className="text-2xl font-bold">Sign In</h1>
        <p className="text-muted-foreground mt-2">Welcome back! Please sign in to your account.</p>
      </div>
      <LoginForm />
    </div>
  )
}
