import { CartPage } from "@/components/cart/cart-page"

export default function Cart() {
  return <CartPage />
}
