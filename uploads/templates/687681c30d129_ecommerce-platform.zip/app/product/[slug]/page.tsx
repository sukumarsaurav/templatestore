import { ProductDetails } from "@/components/products/product-details"
import { ProductRecommendations } from "@/components/products/product-recommendations"

interface ProductPageProps {
  params: {
    slug: string
  }
}

export default function ProductPage({ params }: ProductPageProps) {
  return (
    <div className="container px-4 md:px-6 py-8">
      <ProductDetails slug={params.slug} />
      <ProductRecommendations />
    </div>
  )
}
